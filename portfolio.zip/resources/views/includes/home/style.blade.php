 <!-- Stylesheet -->
<link rel="stylesheet" href="{{asset('home/style.css')}}">