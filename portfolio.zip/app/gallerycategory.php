<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gallerycategory extends Model
{
    protected $fillable = [
        'category'
    ];
}
