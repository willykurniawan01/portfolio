
    <!-- **** All JS Files ***** -->
    <!-- jQuery 2.2.4 -->
    <script src="{{asset('home/js/jquery.min.js')}}"></script>
    <!-- Popper -->
    <script src="{{asset('home/js/popper.min.js')}}"></script>
    <!-- Bootstrap -->
    <script src="{{asset('home/js/bootstrap.min.js')}}"></script>
    <!-- All Plugins -->
    <script src="{{asset('home/js/alime.bundle.js')}}"></script>
    <!-- Active -->
    <script src="{{asset('home/js/default-assets/active.js')}}"></script>