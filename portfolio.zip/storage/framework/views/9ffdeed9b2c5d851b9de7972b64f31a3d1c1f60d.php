 <!-- Stylesheet -->
<link rel="stylesheet" href="<?php echo e(asset('home/style.css')); ?>"><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/includes/home/style.blade.php ENDPATH**/ ?>