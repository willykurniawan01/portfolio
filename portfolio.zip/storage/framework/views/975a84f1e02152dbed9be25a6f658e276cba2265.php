

<?php $__env->startSection('title','Edit Post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
             <?php endif; ?>
      
            <form action="<?php echo e(route('post-update',$item->id)); ?>" method="post" enctype="multipart/form-data">     
                <?php echo method_field('PUT'); ?>  
                <?php echo csrf_field(); ?>
                <div class="input-group input-group-lg">
                    <div class="input-group-prepend">
                    <span class="input-group-text" id="inputGroup-sizing-lg">Title</span>
                    </div>
                <input type="text" class="form-control" name="title" value="<?php echo e($item->title); ?>" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-lg">
                </div>

            <img class="mt-4 img-thumbnail" style="width: 400px; height:300px;" src="<?php echo e(Storage::url($item->picture)); ?>" alt="">
                <div class="input-group mt-4">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroupFileAddon01">Ganti Gambar</span>
                    </div>

                <div class="custom-file">
                        <input type="file" class="custom-file-input" name="picture" id="inputGroupFile01" aria-describedby="inputGroupFileAddon01">
                        <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                </div>
                </div>

                <div class="form-group mt-4">
                <textarea class="form-control" id="editor1" name="post" rows="3"><?php echo e($item->post); ?></textarea>
                  </div>
                
                  <button type="submit" class="btn btn-lg btn-warning">
                      Upload
                  </button>
                <a href="<?php echo e(route('post')); ?>" class="btn btn-lg btn-warning">Back</a>
            </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('ckeditor'); ?>
    <script src="https://cdn.ckeditor.com/4.15.0/standard/ckeditor.js"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('ckeditor-script'); ?>
<script>
    CKEDITOR.replace( 'editor1' );
</script>
<?php $__env->stopPush(); ?>
    
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/pages/admin/post/edit.blade.php ENDPATH**/ ?>