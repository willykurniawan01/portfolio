  <!-- Footer Area Start -->
  <footer class="footer-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="footer-content d-flex align-items-center justify-content-between">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;
                            <script>document.write(new Date().getFullYear());</script> All rights reserved 
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                    <!-- Footer Logo -->
                    <div class="footer-logo">
                        <a href="#"><img src="img/core-img/logo2.png" alt=""></a>
                    </div>
                    <!-- Social Info -->
                    <div class="social-info">
                        <a href="#"><i class="ti-facebook" aria-hidden="true"></i></a>
                        <a href="#"><i class="ti-twitter-alt" aria-hidden="true"></i></a>
                        <a href="#"><i class="ti-linkedin" aria-hidden="true"></i></a>
                        <a href="#"><i class="ti-pinterest" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Footer Area End -->
