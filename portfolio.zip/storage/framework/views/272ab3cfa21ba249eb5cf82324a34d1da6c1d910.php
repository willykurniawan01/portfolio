
    <!-- **** All JS Files ***** -->
    <!-- jQuery 2.2.4 -->
    <script src="<?php echo e(asset('home/js/jquery.min.js')); ?>"></script>
    <!-- Popper -->
    <script src="<?php echo e(asset('home/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo e(asset('home/js/bootstrap.min.js')); ?>"></script>
    <!-- All Plugins -->
    <script src="<?php echo e(asset('home/js/alime.bundle.js')); ?>"></script>
    <!-- Active -->
    <script src="<?php echo e(asset('home/js/default-assets/active.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\portfolio\resources\views/includes/home/script.blade.php ENDPATH**/ ?>